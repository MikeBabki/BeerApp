//
//  PasswordTextFiledView.swift
//  NewApp5.11
//
//  Created by Макар Тюрморезов on 09.12.2022.
//

import UIKit

protocol PasswordTextFieldProtocol: AnyObject {

    func takeString(textField: UITextField, value: String)
    
}

class PasswordTextFiledView: UIView {

    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var wrongPasswordLabel: UILabel!
    
    var tfDelegate: PasswordTextFieldProtocol?
    
    //Сделать инит 
    @objc func textFieldDidChange(_ textField: UITextField) {
       
        tfDelegate?.takeString(textField: textField, value: textField.text ?? "")
       
    }
}

extension PasswordTextFiledView {
    
    func setupText() {
        wrongPasswordLabel.font = .systemFont(ofSize: 11, weight: .medium)
        wrongPasswordLabel.textColor = .red
    }
    
}

extension PasswordTextFiledView: UITextFieldDelegate {
    
  
    
}
