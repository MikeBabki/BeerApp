//
//  EmailTextFieldView.swift
//  NewApp5.11
//
//  Created by Макар Тюрморезов on 09.12.2022.
//

import UIKit

class EmailTextFieldView: UIView {
    @IBOutlet weak var emailTextfield: UITextField!
     @IBOutlet weak var wrongEmailLabel: UILabel!
   
    override func draw(_ rect: CGRect) {
        
    }
}
extension EmailTextFieldView {
    
    func setupText() {
        wrongEmailLabel.font = .systemFont(ofSize: 11, weight: .medium)
        wrongEmailLabel.textColor = .red
    }
    
}
